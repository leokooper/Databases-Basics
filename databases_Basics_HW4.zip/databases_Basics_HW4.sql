USE databases_Basics_HW4;

#Задание 1

CREATE VIEW `cities_view` AS SELECT `cities`.`id` AS `№ п/п`, `cities`.`title` AS `Города`, `countries`.`title` AS `Страны` FROM `cities`, `countries` WHERE `cities`.`country_id` = `countries`.`id`;

CREATE VIEW `countries_view` AS SELECT `cities`.`id` AS `№ п/п`, `cities`.`title` AS `Города`, `countries`.`title` AS `Страны` FROM `cities`, `countries` WHERE `cities`.`country_id` = `countries`.`id`;

DROP VIEW `cities_view`;

CREATE VIEW `regions_view` AS SELECT `cities`.`id` AS `№ п/п`, `cities`.`title` AS `Города`, `regions`.`title` AS `Регионы`  FROM `cities`, `regions` WHERE `cities`.`country_id` = `regions`.`id`;

CREATE VIEW `russian_cities` AS SELECT `cities`.`title` AS `Города России` FROM `cities` WHERE `cities`.`country_id` = 7;

CREATE VIEW `avg_salary` AS SELECT AVG(`salary`) AS `Средняя зарплата`, `depart_id` FROM `Employees` GROUP BY `depart_id`;

CREATE VIEW `max_salary` AS SELECT `name`, `surname`, `salary` FROM `Employees` WHERE `salary`=(SELECT MAX(`salary`) FROM `Employees`);

CREATE VIEW `employees_count` AS SELECT COUNT(`name`) FROM `Employees`;

CREATE VIEW `employees_avg_salary` AS SELECT COUNT(`name`) AS `Количество сотрудников в отделе`, SUM(`salary`) AS `Зарплата сотрудников в отделе`, `Departments`.`title` AS `Отдел` FROM `Employees` LEFT JOIN (`Departments`) ON (`Employees`.`depart_id` = `Departments`.`id`) GROUP BY `depart_id` ;

#Задание 2
#Процедура
USE `databases_Basics_HW4`;
DROP procedure IF EXISTS `find_manager`;

DELIMITER $$
USE `databases_Basics_HW4`$$
CREATE PROCEDURE `find_manager`(IN `mng_name` VARCHAR(40), IN `mng_surname` VARCHAR(40))
BEGIN
SELECT * FROM `databases_Basics_HW4`.`Employees` WHERE `name` COLLATE utf8mb4_general_ci = `mng_name` AND `surname` COLLATE utf8mb4_general_ci = `mng_surname`;
END$$

DELIMITER ;

#Функция
USE `databases_Basics_HW4`;
DROP function IF EXISTS `mng_info`;

DELIMITER $$
USE `databases_Basics_HW4`$$
CREATE FUNCTION `mng_info`( `mng_name` VARCHAR(40), `mng_surname` VARCHAR(40)) RETURNS varchar(255) CHARSET utf8mb4
    READS SQL DATA
    DETERMINISTIC
BEGIN
DECLARE `fullinfo` varchar(255);
SELECT CONCAT_WS(' ', `id`, `databases_Basics_HW4`.`Employees`.`name`, `databases_Basics_HW4`.`Employees`.`surname`, `databases_Basics_HW4`.`Employees`.`salary`) INTO `fullinfo` FROM `databases_Basics_HW4`.`Employees` WHERE `databases_Basics_HW4`.`Employees`.`name` COLLATE utf8mb4_general_ci =`mng_name` AND `databases_Basics_HW4`.`Employees`.`surname` COLLATE utf8mb4_general_ci = `mng_surname`;
RETURN fullinfo;
END$$

DELIMITER ;

#Задание 3
DELIMITER $$
CREATE TRIGGER `add_salary_bonus` BEFORE INSERT ON `databases_Basics_HW4`.`Employees` 
FOR EACH ROW
BEGIN
SET NEW.`salary` = NEW.`salary` + 10000;
END

INSERT INTO `Employees` (`name`, `surname`, `salary`, `depart_id`) VALUES ('Bro', 'Bro', 10000, 1);






